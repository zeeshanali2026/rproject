library(shiny)
library(readxl)
library(ggplot2)
library(randomForest)

# Source the ui.R file
source("ui.R", local = TRUE)

# Server function
server <- function(input, output) {
  
  # Load the initial data from the Excel file
  data <- reactive({
    read_excel("Zeeshan.xlsx")
  })
  
  # Descriptive Statistics
  output$summaryTable <- renderTable({
    req(data())
    summary(data())
  })
  
  # Normal Distribution
  output$normalPlot <- renderPlot({
    req(data())
    data_mean <- mean(data()$uid)
    data_sd <- sd(data()$uid)
    dnorm_values <- dnorm(data()$uid, data_mean, data_sd)
    plot(data()$uid, dnorm_values,
         main = "Normal Distribution of uid",
         col = "blue",
         xlab = "uid",
         ylab = "Density")
  })
  
  output$cumulativePlot <- renderPlot({
    req(data())
    data_mean <- mean(data()$uid)
    data_sd <- sd(data()$uid)
    pnorm_values <- pnorm(data()$uid, data_mean, data_sd)
    plot(data()$uid, pnorm_values,
         main = "Cumulative Normal Distribution of uid",
         col = "blue",
         xlab = "uid",
         ylab = "Cumulative Probability")
  })
  
  output$qqPlot <- renderPlot({
    req(data())
    qqnorm(data()$uid,
           main = "QQ Plot of Normal Distribution for uid",
           col = "blue")
    qqline(data()$uid, col = "red")
  })
  
  output$histogramPlot <- renderPlot({
    rnorm_values <- rnorm(50)
    hist(rnorm_values,
         main = "Histogram of Random Normal Distribution",
         col = "blue",
         xlab = "Values",
         ylab = "Frequency")
  })
  
  # Simple Linear Regression
  output$slrHistogram <- renderPlot({
    req(data())
    hist(data()$Income, main = "Income Distribution", xlab = "Income")
  })
  
  output$slrScatterPlot <- renderPlot({
    req(data())
    plot(data()$Houses ~ data()$Income, main = "Houses vs Income", xlab = "Income", ylab = "Houses")
  })
  
  output$slrDiagPlots <- renderPlot({
    req(data())
    SLR_DATA.Houses_lm <- lm(Houses ~ Income, data = data())
    par(mfrow = c(2,2))
    plot(SLR_DATA.Houses_lm)
    par(mfrow = c(1,1))
  })
  
  #Multiple Linear Regression
  output$slrHistogram <- renderPlot({
    req(data())
    hist(data()$Income, main = "Income Distribution", xlab = "Income")
  })
  
  
  output$mlrScatterPlot <- renderPlot({
    req(data())
    plot(data()$Houses ~ data()$ratio, data = data())
    plot(data()$Houses ~ data()$Income, data = data())
  })
  
  output$mlrDiagPlots <- renderPlot({
    req(data())
    MLR_MODEL <- lm(Houses ~ ratio + Income, data = data())
    par(mfrow = c(2, 2))
    plot(MLR_MODEL)
    par(mfrow = c(1, 1))
  })
  
  output$mlrPredictPlot <- renderPlot({
    req(data())
    MLR_DATA <- expand.grid(
      ratio = seq(min(data()$ratio), max(data()$ratio), length.out = 30),
      Income = c(min(data()$Income), mean(data()$Income), max(data()$Income))
    )
    MLR_DATA$predicted.y <- predict(MLR_MODEL, newdata = MLR_DATA)
    MLR_DATA$Income <- round(MLR_DATA$Income, digits = 2)
    MLR_DATA$Income <- as.factor(MLR_DATA$Income)
    ggplot(data = MLR_DATA, aes(x = ratio, y = Houses)) +
      geom_point() +
      geom_line(data = MLR_DATA, aes(x = ratio, y = predicted.y, color = Income), size = 1.25) +
      theme_bw() +
      labs(
        title = "Rates of Houses Building as a function of Ratio and Income",
        x = "Ratio of Income to House Build",
        y = "New House Building",
        color = "Income"
      )
  })
  
  #Decision Tree
  output$decisionTreePlot <- renderPlot({
    req(data())
    decision_data <- data()
    output.tree <- ctree(Income ~ Houses + ratio + uid, data = decision_data)
    plot(output.tree)
  })
  
  #Random Forest
  output$randomForestPlot <- renderPlot({
    req(data())
    city_data <- data()
    Feature_extraction <- function(data) {
      labels <- c("Houses", "boro", "zipcode")
      features <- data[, labels]
      features$Houses[is.na(features$Houses)] <- median(features$Houses, na.rm = TRUE)
      features$boro <- as.factor(features$boro)
      features$zipcode[is.na(features$zipcode)] <- median(features$zipcode, na.rm = TRUE)
      return(features)
    }
    city_features <- Feature_extraction(city_data)
    rf_model <- randomForest(Houses ~ ., data = city_features, ntree = 100)
    plot(rf_model)
  })
  
  output$variableImportancePlot <- renderPlot({
    req(data())
    city_data <- data()
    Feature_extraction <- function(data) {
      labels <- c("Houses", "boro", "zipcode")
      features <- data[, labels]
      features$Houses[is.na(features$Houses)] <- median(features$Houses, na.rm = TRUE)
      features$boro <- as.factor(features$boro)
      features$zipcode[is.na(features$zipcode)] <- median(features$zipcode, na.rm = TRUE)
      return(features)
    }
    city_features <- Feature_extraction(city_data)
    rf_model <- randomForest(Houses ~ ., data = city_features, ntree = 100)
    importance_scores <- importance(rf_model)
    importance_data <- data.frame(Feature = row.names(importance_scores))
    importance_data$Importance <- importance_scores[,1]
    ggplot(data = importance_data, aes(x = reorder(Feature, Importance), y = Importance)) +
      geom_bar(stat = 'identity', fill = 'steelblue') +
      theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
      labs(x = 'Feature', y = 'Importance', title = 'Variable Importance Plot')
  })
  
  #Hypothesis Testing
  output$hypothesisTable <- renderTable({
    req(data())
    T_data <- data()
    x <- T_data$Houses
    y <- T_data$uid
    mu <- mean(T_data$Houses, na.rm = TRUE)
    one_sample_t_test <- t.test(x, mu = mu)
    two_sample_t_test <- t.test(x, y, na.action = na.omit)
    directional_t_test <- t.test(x, mu = mu, alternative = 'greater')
    one_sample_wilcoxon <- wilcox.test(x, exact = FALSE)
    two_sample_wilcoxon <- wilcox.test(x, y, exact = FALSE)
    correlation_test <- cor.test(T_data$zipcode, T_data$borocode, use = "pairwise.complete.obs")
    hypothesis_data <- data.frame(
      Test = c("One Sample T-Test", "Two Sample T-Test", "Directional T-Test",
               "One Sample Wilcoxon Test", "Two Sample Wilcoxon Test", "Correlation Test"),
      Result = c(one_sample_t_test$p.value, two_sample_t_test$p.value, directional_t_test$p.value,
                 one_sample_wilcoxon$p.value, two_sample_wilcoxon$p.value, correlation_test$p.value)
    )
    hypothesis_data
  })
  
  #Time Series Analysis
  output$timeSeriesPlot <- renderPlot({
    req(data())
    TS_Data <- data()
    colnames(TS_Data) <- c("Houses", "Income")
    TS_Data$Income <- as.numeric(TS_Data$Income)
    TS_Data <- TS_Data[nrow(TS_Data):1, ]
    tidy_TS_Data <- data.frame(
      date = as.Date(paste0(2000:2020, "-01-01")),
      TS_House = as.numeric(ts(TS_Data$Houses, start = 2000, end = 2020))
    )
    ggplot(tidy_TS_Data, aes(x = date, y = TS_House)) +
      geom_line(color = "red", size = 1.1) +
      theme_minimal() +
      xlab("Years") +
      ylab("Adding of New Houses in New York City") +
      ggtitle("New House Index", subtitle = "From 2000 to 2020")
  })
}