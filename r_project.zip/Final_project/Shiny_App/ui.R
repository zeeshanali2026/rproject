library(ggpubr)
library(party)
library(randomForest)
library(readxl)
library(shiny)
library(stats)
library(tidyverse)
library(shinythemes)

# This App is Developed By Zeeshan Ali For the Final Project of IT 2023

ui <- fluidPage(
  theme = shinytheme("lumen"),
  tags$head(
    tags$script(src = "https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.min.js"),
    tags$link(rel = "stylesheet", type = "text/css", href = "styles.css")
  ),
  
  titlePanel("Data Analysis App"),
  navbarPage("Let's get started",
             tabPanel(icon("home")),
                        tabPanel(
                          actionButton(
                            inputId = "codeButton",
                            label = "ABOUT",
                            onclick = "window.open('index.html')"
                          )
                        ),
                        tabPanel(a(icon("info-circle"), href = "index.html")),
                        tabPanel(
                          actionButton(
                            inputId = "codeButton",
                            label = "CODES",
                            onclick = "window.open('codes.html')"
                          )
                        )
                        ,
             ),
  tabsetPanel(
    tabPanel("Descriptive Statistics",
             column(
               br(),
               p(
                 "Descriptive statistics in R refers to the process of summarizing and analyzing the basic characteristics and properties of a dataset. It provides a way to understand the key features, patterns, and trends within the data through various statistical measures and graphical representations.",
                 strong("R,"),
                 " being a popular programming language for statistical analysis, offers a wide range of functions and packages to perform descriptive statistics. Here are some commonly used techniques and functions for descriptive statistics in R:",
                 style = "text-align:justify;color:black;background-color:lavender;padding:15px;border-radius:10px"
               ),
               br(),
               p(
                 "
* Obtains a summary of the descriptive statistics using the summary() function.
* Calculates the mean of the uid variable using the mean() function.
* Computes the median of the uid variable using the median() function.
* Determines the mode of the uid variable using a custom getmode() function.
* Calculates the standard deviation of the uid variable using the sd() function..",
                 style = "text-align:justify;color:black;background-color:papayawhip;padding:15px;border-radius:10px"
               ),
               width = 8
             ),
             tableOutput("summaryTable"),
             actionButton("summaryButton", "Update Summary")
    ),
  
    tabPanel("Normal Distribution",
             fluidRow(column(width=2),
                      column(
                        h4(p("Normal Distribution",style="color:black;text-align:center")),
                        width=8,style="background-color:lavender;border-radius: 10px")
             ),
             br(),
             fluidRow(column(width=2, icon("hand-point-right","fa-5x"),align="center"),
                      column(
                        p("In order to make inferences about the results of this modeling process, it is necessary to establish 
                                     normal distribution, and to make things easier we are going to assume that the" , strong("UID"),"(dependent) 
                                     variable is normally distributed; following this assumption, we will try to achieve this:",style="color:black;text-align:justify"),
                        withMathJax(),
                        p('$$H_0:~Y ~ \\sim ~ Normal( ~\\mu ~,~ \\sigma~ )$$',style="color:black;border:1px solid black;background-color:white"),
                        p("In our case we will take as a response variable", strong(em("UID")), "since it represents a big 
                                    safety problem where the physical integrity of the people is threatened. We will try to explain this 
                                    variable through education issues, others related to sports and even through other safety problems. All of these,
                                    represented through the other variables in the dataset",style="color:black;text-align:justify"),
                        width=8,style="background-color:lavender;border-radius: 10px")
             ),
             br(),
             fluidRow(column(width=2),
                      column(
                        p("Let's do it. You are going to find some graphical and analytical tests in order to conclude our results",style="color:black;text-align:center"),
                        width=8,style="background-color:papayawhip;border-radius: 10px")
             ),
             hr(),
             plotOutput("normalPlot"),
             plotOutput("cumulativePlot"),
             plotOutput("qqPlot"),
             plotOutput("histogramPlot"),
             actionButton("normalButton", "Update Plots")
    ),
    tabPanel("Simple Linear Regression",
             fluidRow(column(width=2),
                      column(
                        h4(p("Simple Linear Regression",style="color:black;text-align:center")),
                        width=8,style="background-color:lavender;border-radius: 10px")
             ),
             br(),
             fluidRow(column(width=2, icon("hand-point-right","fa-5x"),align="center"),
                      column(
                        p("In R, simple linear regression can be performed using the built-in functions and packages available for statistical analysis. Here's an explanation of how I perform simple linear regression in R:",style="color:black;text-align:justify"),
                        withMathJax(),
                        p('$$y = mx + b$$',style="color:black;border:1px solid black;background-color:white"),
                        p("The simple linear regression in Ris performed using the dataset. It reads the data from an Excel file, summarizes the data, plots a histogram of the income column, creates a scatter plot of houses against income, fits a linear regression model, prints a summary of the model, creates diagnostic plots, and finally creates a scatter plot with a regression line using ggplot2. The code provides visualizations and statistical information to analyze the relationship between income and houses and assess the linear regression model.",style="color:black;text-align:justify"),
                        width=8,style="background-color:lavender;border-radius: 10px")
             ),
             br(),
             fluidRow(column(width=2),
                      column(
                        p("Let's do it. You are going to find some graphical and analytical tests in order to conclude the Simple Linear Regression",style="color:black;text-align:center"),
                        width=8,style="background-color:papayawhip;border-radius: 10px")
             ),
             hr(),
             plotOutput("slrHistogram"),
             plotOutput("slrScatterPlot"),
             plotOutput("slrDiagPlots"),
             actionButton("slrButton", "Update Plots")
    ),
    tabPanel("Multiple Linear Regression",
             fluidRow(column(width=2),
                      column(
                        h4(p("Multiple Linear Regression",style="color:black;text-align:center")),
                        width=8,style="background-color:lavender;border-radius: 10px")
             ),
             br(),
             fluidRow(column(width=2, icon("hand-point-right","fa-5x"),align="center"),
                      column(
                        p("Multiple linear regression is an extension of simple linear regression that allows for modeling the relationship between a dependent variable and multiple independent variables. Instead of just one predictor variable, multiple linear regression considers two or more predictor variables to explain the variation in the dependent variable.

The general form of the multiple linear regression model can be represented as:",style="color:black;text-align:justify"),
                        withMathJax(),
                        p('$$y = b0 + b1x1 + b2x2 + ... + bnxn + ε$$',style="color:black;border:1px solid black;background-color:white"),
                        p("In my case,tThe provided code performs multiple linear regression in R using the dataset. It loads the necessary libraries, reads the data from an Excel file, summarizes the data, calculates the correlation, plots histograms and scatter plots, fits a multiple linear regression model, prints the model summary, creates diagnostic plots, and finally creates a scatter plot with predicted values. The code provides visualizations and statistical information to analyze the relationship between the predictors and the dependent variable, as well as the performance of the regression model.",style="color:black;text-align:justify"),
                        width=8,style="background-color:lavender;border-radius: 10px")
             ),
             br(),
             fluidRow(column(width=2),
                      column(
                        p("Let's do it. You are going to find some graphical and analytical tests in order to conclude about the Multiple Linear Regression",style="color:black;text-align:center"),
                        width=8,style="background-color:papayawhip;border-radius: 10px")
             ),
             hr(),
             plotOutput("mlrHistogram"),
             plotOutput("mlrScatterPlot"),
             plotOutput("mlrDiagPlots"),
             plotOutput("mlrPredictPlot"),
             actionButton("mlrButton", "Update Plots")
    ),
    tabPanel("Decision Tree",
             fluidRow(column(width=2),
                      column(
                        h4(p("Decision Tree",style="color:black;text-align:center")),
                        width=8,style="background-color:lavender;border-radius: 10px")
             ),
             br(),
             fluidRow(column(width=2, icon("hand-point-right","fa-5x"),align="center"),
                      column(
                        p("A decision tree is a popular machine learning algorithm used for both classification and regression tasks. It is a tree-like model where each internal node represents a feature or attribute, each branch represents a decision rule based on that feature, and each leaf node represents an outcome or prediction. Decision trees recursively partition the data based on the feature values, making binary decisions at each node, until a stopping condition is met:",style="color:black;text-align:justify"),
                        withMathJax(),
                        p('$$IF condition THEN decision
ELSE
   IF condition THEN decision
   ELSE
      IF condition THEN decision
      ELSE ...$$',style="color:black;border:1px solid black;background-color:white"),
                        p("The provided are made by performing a decision tree analysis on the  dataset. It imports the data from an Excel file, splits it into training and testing sets, and creates a decision tree model using the Income variable as the dependent variable and Houses, Ratio, and UID as predictors. The code then visualizes the decision tree.",style="color:black;text-align:justify"),
                        width=8,style="background-color:lavender;border-radius: 10px")
             ),
             br(),
             fluidRow(column(width=2),
                      column(
                        p("Let's do it. You are going to find some graphical and analytical tests in order to conclude about the Decision Tree",style="color:black;text-align:center"),
                        width=8,style="background-color:papayawhip;border-radius: 10px")
             ),
             hr(),
             plotOutput("decisionTreePlot"),
             actionButton("dtButton", "Update Plot")
    ),
    tabPanel("Random Forest",
             fluidRow(column(width=2),
                      column(
                        h4(p("Random Forest",style="color:black;text-align:center")),
                        width=8,style="background-color:lavender;border-radius: 10px")
             ),
             br(),
             fluidRow(column(width=2, icon("hand-point-right","fa-5x"),align="center"),
                      column(
                        p("Random Forest is a popular ensemble learning algorithm that combines multiple decision trees to make predictions. It is widely used for both classification and regression tasks. To use Random Forest in R, you can use the randomForest package. By fitting a Random Forest model, you can train the ensemble of decision trees and make predictions on new data. The package provides various options and parameters to control the model's behavior, such as the number of trees, feature selection criteria, and parallel processing.",style="color:black;text-align:justify"),
                        withMathJax(),
                        p('$$Train the Random Forest model --> Make Predictions$$',style="color:black;border:1px solid black;background-color:white"),
                        p("The provided code performs a Random Forest analysis on the city_data dataset.

Feature Extraction:
The code extracts relevant features from the dataset, including Houses, boro, and zipcode. It handles missing values in Houses and zipcode by replacing them with the median.

Summary of Extracted Features:
The code provides a summary of the extracted features, giving statistical information such as mean, median, and quartiles.

Random Forest Model Training:
The code trains a Random Forest model using the extracted features as predictors and the Houses variable as the target variable. It builds 100 decision trees (specified by the ntree parameter) using the randomForest() function.

Model Summary:
The code prints the summary of the Random Forest model, which includes information about the number of trees, the mean square error, and the out-of-bag error estimate.

Importance Scores:
The code calculates and prints the importance scores of the features in the Random Forest model using the importance() function. These scores indicate the relative importance of each feature in predicting the target variable.",style="color:black;text-align:justify"),
                        width=8,style="background-color:lavender;border-radius: 10px")
             ),
             br(),
             fluidRow(column(width=2),
                      column(
                        p("Let's do it. You are going to find some graphical and analytical tests in order to conclude about the Random Forest",style="color:black;text-align:center"),
                        width=8,style="background-color:papayawhip;border-radius: 10px")
             ),
             hr(),
             plotOutput("randomForestPlot"),
             plotOutput("variableImportancePlot"),
             actionButton("rfButton", "Update Plots")
    ),
    tabPanel("Hypothesis Testing",
             fluidRow(column(width=2),
                      column(
                        h4(p("Hypothesis Testing",style="color:black;text-align:center")),
                        width=8,style="background-color:lavender;border-radius: 10px")
             ),
             br(),
             fluidRow(column(width=2, icon("hand-point-right","fa-5x"),align="center"),
                      column(
                        p("Hypothesis testing is a statistical method used to make inferences and draw conclusions about a population based on sample data. It involves formulating two competing hypotheses, known as the null hypothesis (H0) and the alternative hypothesis (Ha). The goal is to gather evidence from the data to either support or reject the null hypothesis in favor of the alternative hypothesis:",style="color:black;text-align:justify"),
                        withMathJax(),
                        p('$$t ∗ = x ¯ − μ s / n$$',style="color:black;border:1px solid black;background-color:white"),
                        p("The provided code performs various hypothesis tests using statistical functions in R. It includes:

One Sample T-Test: Tests if the mean of the Houses column significantly differs from a specified value.
Two Sample T-Test: Compares the means of the Houses and uid columns.
Directional Hypothesis Testing: Tests if the mean of the Houses column is significantly greater than a specified value.
One Sample Wilcoxon Test: Non-parametric test to compare the distribution of the Houses column against a specified value.
Two Sample Wilcoxon Test: Non-parametric test to compare the distributions of the Houses and uid columns.
Correlation Test: Tests the correlation between the zipcode and borocode columns.
Each test provides results such as test statistics, p-values, and confidence intervals. These results help assess the statistical significance of the observed data and make conclusions about the hypotheses being tested.",style="color:black;text-align:justify"),
                        width=8,style="background-color:lavender;border-radius: 10px")
             ),
             br(),
             fluidRow(column(width=2),
                      column(
                        p("Let's do it. You are going to find some analytical tests in order to conclude about the Hypothesis Testing",style="color:black;text-align:center"),
                        width=8,style="background-color:papayawhip;border-radius: 10px")
             ),
             hr(),
             tableOutput("hypothesisTable"),
             actionButton("hypothesisButton", "Update Table")
    ),
    tabPanel("Time Series Analysis",
             fluidRow(column(width=2),
                      column(
                        h4(p("Time Series Analysis",style="color:black;text-align:center")),
                        width=8,style="background-color:lavender;border-radius: 10px")
             ),
             br(),
             fluidRow(column(width=2, icon("hand-point-right","fa-5x"),align="center"),
                      column(
                        p("Time series analysis is a statistical method used to analyze and forecast data that is collected over time. It involves studying patterns, trends, and relationships within the data to make predictions about future values. In R, there are several packages and functions available for time series analysis, including the stats, forecast, and xts packages.",style="color:black;text-align:justify"),
                        withMathJax(),
                        p('$$ Adding of New Houses Over Time $$',style="color:black;border:1px solid black;background-color:white"),
                        p("The provided code performs time series analysis and visualization of the TS_Data dataset in R.

Data Preprocessing:

The code reads the data from an Excel file, assigns column names, and converts the Income column to numeric.
It reverses the order of the dataframe.
Time Series Creation:

The code creates a time series object named TS_House using the Houses column from the data.
Data Plotting:

The code creates a line plot using ggplot, with the date range from 2000 to 2020 on the x-axis and the number of new houses on the y-axis.
The plot is customized with labels and titles.
The result is a plot showing the trend of the number of new houses in New York City from 2000 to 2020.",style="color:black;text-align:justify"),
                        width=8,style="background-color:lavender;border-radius: 10px")
             ),
             br(),
             fluidRow(column(width=2),
                      column(
                        p("Let's do it. You are going to find some graphical and analytical tests in order to conclude about the Time Series Analysis",style="color:black;text-align:center"),
                        width=8,style="background-color:papayawhip;border-radius: 10px")
             ),
             hr(),
             plotOutput("timeSeriesPlot"),
             actionButton("timeSeriesButton", "Update Plot")
    )
  )
)
