# Part I: Animation in R

setwd("C:/Users/zeeshan.ali/OneDrive - University Of Central Asia/Desktop/Final_Assignment")

# Load the necessary library
library(plotly)
library(lubridate)

wind_power <- read.csv("Zeeshan_wind-power-production-us.csv")

# Dates are in the format "Month-Year" 
wind_power$date <- as.Date(paste0("01-", wind_power$date), format="%d-%b-%y")

# Extract the year
wind_power$year <- year(wind_power$date)

# Create a simple animated scatter plot using plotly
p <- wind_power %>%
  plot_ly(
    x = ~other_united_states, 
    y = ~wind_united_states, 
    frame = ~year, # this creates the animation
    type = "scatter",
    mode = "markers",
    text = ~paste('Year:', year, '<br>Other Power:', other_united_states, '<br>Wind Power:', wind_united_states),
    hoverinfo = "text",
    marker = list(size = 15, color = 'rgba(152, 0, 0, .8)', line = list(width = 2, color = 'rgb(0, 0, 0)')) 
  ) 

# Add animation options and layout specifications
p <- p %>% animation_opts(1000, easing = "cubic-in-out") %>%
  layout(
    title = "Wind Power in US vs Other Power in US over Date",
    xaxis = list(title = "Other Power", gridcolor = 'rgb(255, 255, 255)', zerolinewidth = 1, ticklen = 5, gridwidth = 2), 
    yaxis = list(title = "Wind Power", gridcolor = 'rgb(255, 255, 255)', zerolinewidth = 1, ticklen = 5, gridwidth = 2), 
    paper_bgcolor = 'rgb(243, 243, 243)',
    plot_bgcolor = 'rgb(243, 243, 243)'
  )

# Print the figure
print(p)

# Part II: Machine Learning in R

# Loading The tidyverse Package 
library(tidyverse)

# Read the CSV dataset
data <- read.csv("Zeeshan_ML_Churn_Modelling.csv")

# Display the first few rows of the dataset
head(data)

# Summary statistics
summary(data)

# Count the number of missing values in each column
colSums(is.na(data))

# Data visualization

# Histogram of CreditScore
ggplot(data, aes(x = CreditScore)) +
  geom_histogram(binwidth = 20, fill = "skyblue", color = "black") +
  labs(x = "Credit Score", y = "Frequency", title = "Histogram of Credit Score")

# Boxplot of Age by Geography
ggplot(data, aes(x = Geography, y = Age)) +
  geom_boxplot(fill = "skyblue", color = "black") +
  labs(x = "Geography", y = "Age", title = "Boxplot of Age by Geography")

# Bar plot of Gender
ggplot(data, aes(x = Gender, fill = Gender)) +
  geom_bar() +
  labs(x = "Gender", y = "Count", title = "Bar Plot of Gender") +
  scale_fill_manual(values = c("Female" = "pink", "Male" = "skyblue"))

# Scatter plot of Balance vs. EstimatedSalary
ggplot(data, aes(x = Balance, y = EstimatedSalary)) +
  geom_point(color = "darkblue", alpha = 0.5) +
  labs(x = "Balance", y = "Estimated Salary", title = "Scatter Plot of Balance vs. Estimated Salary")

# Load the Necessary ibraries 
library(tidyverse)
library(caret)
library(randomForest)
library(e1071)
library(nnet)
library(rpart)
library(gbm)
library(kernlab)
library(rpart.plot)

# -	Load in the data

# Read the dataset
data <- read.csv("Zeeshan_ML_Churn_Modelling.csv")

# -	Clean the data

# Subset to first 100 rows
data <- data[1:100, ]

# Print the dataset
print(data)

# Remove the third column (Surname)
data <- data[, -3]

# -	Split the Data into Training/Test sets

# Set seed for reproducibility
set.seed(123)

# Determine the number of rows for training (75% of total rows)
train_rows <- sample(1:nrow(data), 0.75 * nrow(data))

# Split the data
trainData <- data[train_rows, ]
testData <- data[-train_rows, ]

# -	Create a Model and Build 5 machine-learning models and Train the Model
# 1.Random Forest
# 2.rpart
# 3.SVM
# 4.Neural Network
# 5.Kernel SVM

# Random Forest
model_rf <- randomForest(Exited ~ ., data = trainData)
print(model_rf)
importance(model_rf)

# rpart
model_rpart <- rpart(Exited ~ ., data = trainData, method = "class")
print(model_rpart)
rpart.plot(model_rpart)

# SVM
model_svm <- svm(Exited ~ ., data = trainData)

# Neural Network
model_nnet <- nnet(Exited ~ ., data = trainData, size = 10, rang = 0.1, decay = 5e-4, maxit = 200)

# Kernel SVM
model_ksvm <- ksvm(Exited ~ ., data = trainData, kernel = "vanilladot")

# -	Make Predictions

# Random Forest predictions
pred_rf <- predict(model_rf, newdata = testData)

# rpart predictions
predictions_rpart <- predict(model_rpart, newdata = testData, type = "class")

# SVM predictions
pred_svm <- predict(model_svm, newdata = testData)

# Neural Network predictions
pred_prob <- predict(model_nnet, newdata = testData, type = "raw")
pred_nnet <- ifelse(pred_prob > 0.5, 1, 0)

# Kernel SVM predictions
pred_ksvm <- predict(model_ksvm, newdata = testData)

# -	Evaluate the Model

# Evaluate the Random Forest model
rf_predictions <- predict(model_rf, newdata = testData)
rf_accuracy <- mean(rf_predictions == testData$Exited)
print(paste("Random Forest Accuracy:", rf_accuracy))

# Evaluate the rpart model
rpart_predictions <- predict(model_rpart, newdata = testData, type = "class")
rpart_accuracy <- mean(rpart_predictions == testData$Exited)
print(paste("rpart Accuracy:", rpart_accuracy))

# Evaluate the SVM model
svm_predictions <- predict(model_svm, newdata = testData)
svm_accuracy <- mean(svm_predictions == testData$Exited)
print(paste("SVM Accuracy:", svm_accuracy))

# Evaluate the Neural Network model
nnet_predictions <- ifelse(pred_prob > 0.5, 1, 0)
nnet_accuracy <- mean(nnet_predictions == testData$Exited)
print(paste("Neural Network Accuracy:", nnet_accuracy))

# Evaluate the Kernel SVM model
ksvm_predictions <- predict(model_ksvm, newdata = testData)
ksvm_accuracy <- mean(ksvm_predictions == testData$Exited)
print(paste("Kernel SVM Accuracy:", ksvm_accuracy))

cat("Out of 5 prediction models, rPart, and Neural Network accuracy is more (0.76), SO they are the best!")

# -	Evaluate and improve, Model improvement for rpart
# Tune the parameters of the rpart model
tuned_rpart <- rpart(Exited ~ ., data = trainData, method = "class", control = rpart.control(cp = 0.02)) 
print(tuned_rpart)
rpart.plot(tuned_rpart)

# Evaluate the tuned rpart model
tuned_rpart_predictions <- predict(tuned_rpart, newdata = testData, type = "class")
tuned_rpart_accuracy <- mean(tuned_rpart_predictions == testData$Exited)
print(paste("Tuned rpart Accuracy:", tuned_rpart_accuracy))

# Model improvement for Neural Network
# Update the architecture and training parameters
updated_nnet <- nnet(Exited ~ ., data = trainData, size = 20, decay = 1e-5, maxit = 500)
print(updated_nnet)

# Evaluate the updated Neural Network model
updated_nnet_predictions <- ifelse(predict(updated_nnet, newdata = testData, type = "raw") > 0.5, 1, 0)
updated_nnet_accuracy <- mean(updated_nnet_predictions == testData$Exited)
print(paste("Updated Neural Network Accuracy:", updated_nnet_accuracy))

cat("Since, after trying evualting and improvement, the accuracy remain same")

